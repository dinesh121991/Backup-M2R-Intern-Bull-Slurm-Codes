for i in {0..40}; do slurmd -N virtual$i; done
