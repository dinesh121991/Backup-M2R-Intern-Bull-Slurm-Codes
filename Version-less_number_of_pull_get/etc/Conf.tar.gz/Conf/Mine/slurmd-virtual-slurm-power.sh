for i in {0..40}; do /usr/local/slurm-powercap/sbin/slurmd -N virtual$i; done
