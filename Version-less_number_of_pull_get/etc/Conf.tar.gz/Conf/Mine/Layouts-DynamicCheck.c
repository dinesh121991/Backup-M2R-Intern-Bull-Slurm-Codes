#include<stdio.h>

int i;

int main()
{
	char *base="Dineshkumar";
	char b[10][30];
		for( i=0; i<9 ;i++ )
		{
			sprintf(b[i],"%s%d",base,i);	
		}
	char s[10][30]={
		for(i=0;i<9;i++)
		{
			{b[i]}
		}
	};
}
