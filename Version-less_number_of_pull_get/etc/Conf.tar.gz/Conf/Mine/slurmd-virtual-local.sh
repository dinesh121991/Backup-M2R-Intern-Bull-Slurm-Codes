for i in {0..229}; do /usr/local/sbin/slurmd -N virtual$i; done
