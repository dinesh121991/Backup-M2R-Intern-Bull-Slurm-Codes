for i in {0..40}; do /usr/local/select-cons-res/sbin/slurmd -N virtual$i; done
