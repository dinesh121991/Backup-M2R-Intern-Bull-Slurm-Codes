/** TODO: copyright notice */

#include "slurm/slurm.h"

#include "src/common/layouts_mgr.h"
#include "src/common/entity.h"
#include "src/common/log.h"
//add Power Cap?
const char plugin_name[] = "Power layout";
const char plugin_type[] = "layouts/power";
const uint32_t plugin_version = 100;

//CurrentPower=0 CurrentFreq=0 IdleWatts=103 MaxWatts=308 Cpufreq12Watts=172 Cpufreq14Watts=187 Cpufreq16Watts=203 Cpufreq18Watts=226 Cpufreq20Watts=252 Cpufreq22Watts=273 Cpufreq24Watts=29

/* specific options for energy layout */
s_p_options_t entity_options[] = {
	{"CurrentPower", S_P_UINT32},
	{"CurrentFreq", S_P_UINT32},
	{"IdleWatts", S_P_UINT32},
	{"MaxWatts", S_P_UINT32},
	{"Cpufreq1Watts", S_P_UINT32},
	{"Cpufreq2Watts", S_P_UINT32},
	{"Cpufreq3Watts", S_P_UINT32},
	{"Cpufreq4Watts", S_P_UINT32},
	{"Cpufreq5Watts", S_P_UINT32},
	{"Cpufreq6Watts", S_P_UINT32},
	{"Cpufreq7Watts", S_P_UINT32},
	{"Cpufreq8Watts", S_P_UINT32},
	{"Cpufreq1", S_P_UINT32},
        {"Cpufreq2", S_P_UINT32},
        {"Cpufreq3", S_P_UINT32},
        {"Cpufreq4", S_P_UINT32},
        {"Cpufreq5", S_P_UINT32},
        {"Cpufreq6", S_P_UINT32},
        {"Cpufreq7", S_P_UINT32},
        {"Cpufreq8", S_P_UINT32},
	{"PowerCapPriority", S_P_UINT32},
	{"DownWatts",S_P_UINT32},
	{"SaveWatts",S_P_UINT32},
	{"NumFreqChoices",S_P_UINT32},
	{NULL}
};
s_p_options_t options[] = {
	{"Entity", S_P_EXPLINE, NULL, NULL, entity_options},
	{NULL}
};

const layouts_keyspec_t keyspec[] = {
        {"CurrentPower", L_T_UINT32},
        {"CurrentFreq", L_T_UINT32},
        {"IdleWatts", L_T_UINT32},
        {"MaxWatts", L_T_UINT32},
        {"Cpufreq1Watts", L_T_UINT32},
        {"Cpufreq2Watts", L_T_UINT32},
        {"Cpufreq3Watts", L_T_UINT32},
        {"Cpufreq4Watts", L_T_UINT32},
        {"Cpufreq5Watts", L_T_UINT32},
        {"Cpufreq6Watts", L_T_UINT32},
        {"Cpufreq7Watts", L_T_UINT32},
        {"Cpufreq8Watts", L_T_UINT32},
        {"Cpufreq1", L_T_UINT32},
        {"Cpufreq2", L_T_UINT32},
        {"Cpufreq3", L_T_UINT32},
        {"Cpufreq4", L_T_UINT32},
        {"Cpufreq5", L_T_UINT32},
        {"Cpufreq6", L_T_UINT32},
        {"Cpufreq7", L_T_UINT32},
        {"Cpufreq8", L_T_UINT32},
	{"PowerCapPriority", L_T_UINT32},
	{"DownWatts",L_T_UINT32},
	{"SaveWatts",L_T_UINT32},
	{"NumFreqChoices",L_T_UINT32},
	{NULL}
};

/* types allowed in the entity's "type" field */
const char* etypes[] = {
	"Center",
	"Node",
	NULL
};

const layouts_plugin_spec_t plugin_spec = {
	options,
	keyspec,
	LAYOUT_STRUCT_TREE,
	etypes,
	true /* if this evalued to true, keys inside plugin_keyspec present in
	      * plugin_options having corresponding types, are automatically
	      * handled by the layouts manager.
	      */
};

/* manager is lock then this function is called */
/* disable this callback by setting it to NULL, warn: not every callback can
 * be desactivated this way */
int layouts_p_conf_done(
		xhash_t* entities, layout_t* layout, s_p_hashtbl_t* tbl)
{
	return 1;
}


/* disable this callback by setting it to NULL, warn: not every callback can
 * be desactivated this way */
void layouts_p_entity_parsing(
		entity_t* e, s_p_hashtbl_t* etbl, layout_t* layout)
{
}

int init(void)
{
	return SLURM_SUCCESS;
}

int fini(void)
{
	return SLURM_SUCCESS;
}

